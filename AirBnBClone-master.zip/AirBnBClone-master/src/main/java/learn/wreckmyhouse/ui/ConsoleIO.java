package learn.wreckmyhouse.ui;

public class ConsoleIO {
}
