package learn.wreckmyhouse.domain;

public class Result {
}
