package learn.wreckmyhouse.domain;

public class ReservationService {
}
