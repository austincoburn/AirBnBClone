package learn.wreckmyhouse.domain;

public class Response {
}
