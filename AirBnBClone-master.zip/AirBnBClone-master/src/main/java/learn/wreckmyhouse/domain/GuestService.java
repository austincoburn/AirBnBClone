package learn.wreckmyhouse.domain;

public class GuestService {
}
