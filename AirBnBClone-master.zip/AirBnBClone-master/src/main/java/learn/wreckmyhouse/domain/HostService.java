package learn.wreckmyhouse.domain;

public class HostService {
}
