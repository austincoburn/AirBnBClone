package learn.wreckmyhouse;

public class App {
    public static void main(String[] args) {

    }
}
